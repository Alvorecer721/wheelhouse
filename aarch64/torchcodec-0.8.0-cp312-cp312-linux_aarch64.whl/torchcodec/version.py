# Note that this file is generated during install.
__version__ = '0.8.0+e5b6680'
